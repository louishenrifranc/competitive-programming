#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

#include <queue>

int main()
{
    std::freopen("electricity.in",  "r", stdin);
    std::freopen("electricity.out", "w", stdout);

    uint64_t n, m;
    std::cin >> n >> m;

    std::priority_queue<uint64_t> type1;
    std::priority_queue<uint64_t> type2;

    for (uint64_t i=0; i<n; ++i) { uint64_t v; std::cin >> v; type1.push(v); }
    for (uint64_t i=0; i<m; ++i) { uint64_t v; std::cin >> v; type2.push(v); }

    uint64_t R = 1;
    uint64_t A = 1;
    uint64_t B = 0;


    while (true)
    {

        if      (B && !type2.empty()) { --B; A += type2.top(); type2.pop(); }
        else if (A && !type1.empty()) { --A; B += type1.top(); type1.pop(); }
        else break;
        if (R < A) R = A;
    }

    std::cout << R << std::endl;

    return 0;
}
