#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::freopen("garage.in",  "r", stdin);
    std::freopen("garage.out", "w", stdout);

    int64_t W, H, w, h;
    std::cin >> W >> H >> w >> h;


    int64_t fw = W / w;
    int64_t pw = (fw - 1) / 2 + 1;

    int64_t fh = H / h;
    int64_t ph = (fh - 1) / 2 + 1;


    // std::cout << pw << " ";
    // std::cout << ph << " ";
    std::cout << pw*ph << std::endl;

    return 0;
}
