#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

#include <vector>

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::freopen("arrange.in",  "r", stdin);
    std::freopen("arrange.out", "w", stdout);


    uint64_t n;
    std::cin >> n;

    std::string str;
    std::vector<bool> exist(26, false);

    for(uint64_t i=0; i<n; ++i)
    {
        std::cin >> str;
        exist[str[0]-'A'] = true;
    }

    uint64_t i=0;
    while(exist[i]) ++i;

    std::cout << i << std::endl;

    return 0;
}
