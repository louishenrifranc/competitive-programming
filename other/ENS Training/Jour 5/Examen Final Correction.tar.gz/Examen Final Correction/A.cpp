#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

#include <algorithm>

void print(int64_t n)
{
    switch(n)
    {
        case  4: std::cout << "11"; break;
        case  5: std::cout << "17"; break;
        case  6: std::cout << "14"; break;
        case  7: std::cout << "12"; break;
        case  8: std::cout << "01"; break;
        case  9: std::cout << "07"; break;
        case 10: std::cout << "04"; break;
        case 11: std::cout << "02"; break;
        case 12: std::cout << "00"; break;
        case 13: std::cout << "08"; break;
    }
}

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::freopen("alarm.in",  "r", stdin);
    std::freopen("alarm.out", "w", stdout);

    int64_t n;
    std::cin >> n;

    int64_t mi = 4;
    int64_t ma = 13;
    int64_t h  = std::max(mi, n-ma);
    int64_t m  = n - h;

    if (m < mi || h > ma)
        std::cout << "impossible" << std::endl;
    else
    {
        print(h);
        std::cout << ":";
        print(m);
        std::cout << std::endl;
    }

    return 0;
}
