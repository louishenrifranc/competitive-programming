#include <stdio.h>
#include <cmath>

using namespace std;

typedef signed long long int number;

int main()
{
    FILE * inputFile = fopen("final.in", "r");
    FILE * outputFile = fopen("final.out", "w+");

    int drivers;
    int points;
    int top;
    int diff;

    fscanf(inputFile, "%d %d %d %d", &drivers, &points, &top, &diff);

    int * score = new int[drivers];

    for(int i=0; i<drivers; i++){
        score[i] = 0;
    }

    bool impossible = false;

    if(diff == 1){ // top have same score
        if(points % drivers == 0){
            int scorePerDriver = points / drivers;
            for(int i=0; i<drivers; i++){
                score[i] = scorePerDriver;
            }
        }else if(drivers == top){ // all drivers have same score // score should be multiple of drivers
            impossible = true;
        }else{ // top have same score

            int remainder = points % top;
            int scorePerTopDriver = (points-remainder) / top;

            int maxRemainingPoints = scorePerTopDriver * (drivers-top) - 1;

            if(remainder <= maxRemainingPoints){
                int betterDrivers = remainder % (drivers-top);
                int scorePerNormalDriver = (remainder-betterDrivers) / (drivers-top);

                for(int i=0; i<drivers; i++){
                    if(i < top){
                        score[i] = scorePerTopDriver;
                    }else if(i < top+betterDrivers){
                        score[i] = scorePerNormalDriver+1;
                    }else{
                        score[i] = scorePerNormalDriver;
                    }
                }
            }else{
                impossible = true;
            }
        }

    }else{ // top have different score
        int minPointsRequired = (diff*(diff-1)) / 2;

        if(minPointsRequired > points){
            impossible = true;
        }else{
            for(int i=0; i<diff; i++){
                score[i] = diff-1-i;
            }
            score[0] += points - minPointsRequired;
        }
    }

    if(impossible){
        fprintf(outputFile, "Wrong information\n");
    }else{
        for(int i=0; i<drivers; i++){
            fprintf(outputFile, "%d\n", score[i]);
        }
    }

    fclose(inputFile);
    fclose(outputFile);

    return 0;
}
