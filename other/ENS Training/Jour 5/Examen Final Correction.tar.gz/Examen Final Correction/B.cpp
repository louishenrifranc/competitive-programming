#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

#include <vector>
#include <algorithm>

int main()
{
    std::freopen("buffcraft.in",  "r", stdin);
    std::freopen("buffcraft.out", "w", stdout);

    uint64_t b;
    uint64_t k;
    uint64_t n;
    uint64_t m;
    std::cin >> b >> k >> n >> m;

    std::vector<uint64_t> bufff(n);
    std::vector<uint64_t> buffp(m);
    for (uint64_t i=0; i<n; ++i) std::cin >> bufff[i];
    for (uint64_t i=0; i<m; ++i) std::cin >> buffp[i];

    std::vector<std::vector<uint64_t>> dpf(n+1, std::vector<uint64_t>(k+1, 0.0));
    std::vector<std::vector<uint64_t>> dpp(m+1, std::vector<uint64_t>(k+1, 0.0));

    for (uint64_t i=0; i<n; ++i)
    for (uint64_t j=0; j<k; ++j)
    {
        dpf[i+1][j+1] = std::max(dpf[i][j+1], dpf[i][j]+bufff[i]);
    }
    for (uint64_t i=0; i<m; ++i)
    for (uint64_t j=0; j<k; ++j)
    {
        dpp[i+1][j+1] = std::max(dpp[i][j+1], dpp[i][j]+buffp[i]);
    }

    int64_t pos   = 0;
    double  value = b;

    for (uint64_t i=0; i<=k; ++i)
    {
        double vv = (double) (b + dpf[n][i]) * (100.0 + dpp[m][k-i]);
        if (value < vv) { value = vv; pos = i; }
    }

    //===========================================
    std::cout << pos << " " << k - pos << std::endl;

    uint64_t kf = k;
    std::vector<uint64_t> sf;
    for (uint64_t i=n; i>0; --i)
        if (dpf[i][kf] != dpf[i-1][kf])
        {
            sf.push_back(i);
            --kf;
        }

    //===========================================
    for (uint64_t i: sf) std::cout << i << " ";
    std::cout << std::endl;
    //===========================================

    uint64_t kp = k-pos;
    std::vector<uint64_t> sp;
    for (uint64_t i=m; i>0; --i)
    {
        if (dpp[i][kp] != dpp[i-1][kp])
        {
            sp.push_back(i);
            --kp;
        }
    }

    //===========================================
    for (uint64_t i: sp) std::cout << i << " ";
    std::cout << std::endl;
    //===========================================

    return 0;
}
