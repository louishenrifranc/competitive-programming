#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::freopen("deepest.in",  "r", stdin);
    // std::freopen("deepest.out", "w", stdout);
    FILE *out = fopen("deepest.out", "w");

    double x, y, d;
    std::cin >> x >> y >> d;

    double p = sqrt(x*x+y*y);

    if (p>d)
        fprintf(out, "Impossible\n");
    else if (p==d)
        fprintf(out, "Single staircase\n");
    else
    {
        double q = (d-p)/2;
        double xi = q * x / p;
        double yi = q * y / p;
        fprintf(out, "%f %f %f\n", x + xi, y + yi, q);
    }

    fclose(out);

    return 0;
}
