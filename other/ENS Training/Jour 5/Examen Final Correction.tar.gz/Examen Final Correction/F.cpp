#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>

int main()
{
    std::freopen("energy.in",  "r", stdin);
    std::freopen("energy.out", "w", stdout);

    uint64_t n;
    std::string str;
    std::cin >> n >> str;


    uint64_t available = n;
    uint64_t wide      = 0;
    uint64_t narrow    = 0;
    uint64_t total     = 0;

    for (char c : str)
    {
        switch(c)
        {
            case '1':
            {
                if      (available) { --available;         ++narrow; }
                else if (wide)      { ++available; --wide; ++narrow; }
                break;
            }
            case '2':
            {
                if (available >= 2) { available -= 2; wide += 1; }
            }
        }
        total += wide + narrow;
    }
    std::cout << total << std::endl;

    return 0;
}
