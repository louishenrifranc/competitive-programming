#include <cstdlib>
#include <cstdio>
#include <ios>
#include <iostream>
#include <math.h>
#include <time.h>


char grid[10][11];


void initgrid()
{
    for (int64_t i=0; i<10; ++i)
    {
        for (int64_t j=0; j<10; ++j)
            grid[i][j] = '.';
        grid[i][10] = '\0';
    }
}


void fillgrid(int64_t pi, int64_t pj)
{
    pi = std::max((int64_t) 0, pi-3);

    grid[pi+0][pj] = 'X';
    grid[pi+1][pj] = 'X';
    grid[pi+2][pj] = 'X';
    grid[pi+3][pj] = 'X';

    grid[0][(pj+2)%10] = 'X';
    grid[1][(pj+2)%10] = 'X';
    grid[2][(pj+2)%10] = 'X';

    grid[4][(pj+2)%10] = 'X';
    grid[5][(pj+2)%10] = 'X';
    grid[6][(pj+2)%10] = 'X';

    grid[8][(pj+2)%10] = 'X';
    grid[9][(pj+2)%10] = 'X';

    grid[0][(pj+4)%10] = 'X';
    grid[1][(pj+4)%10] = 'X';

    grid[5][(pj+4)%10] = 'X';
    grid[6][(pj+4)%10] = 'X';

    grid[0][(pj+6)%10] = 'X';

    grid[2][(pj+6)%10] = 'X';

    grid[4][(pj+6)%10] = 'X';

    grid[6][(pj+6)%10] = 'X';
}



int main()
{
    std::ios_base::sync_with_stdio(false);
    std::freopen("battleship.in",  "r", stdin);
    std::freopen("battleship.out", "w", stdout);

    int64_t pi = 0, pj = 0;
    for (int64_t i=0; i<10; ++i)
    for (int64_t j=0; j<10; ++j)
    {
        int64_t v; std::cin >> v;
        if (v==100) { pi = i; pj = j; }
    }

    initgrid();
    fillgrid(pi, pj);

    for (int64_t i=0; i<10; ++i)
        std::cout << grid[i] << std::endl;

    return 0;
}
